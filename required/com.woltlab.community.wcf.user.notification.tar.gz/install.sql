--
-- Table structure for table 'wcf1_user_notification'
--

DROP TABLE IF EXISTS wcf1_user_notification;
CREATE TABLE wcf1_user_notification (
  notificationID int(10) NOT NULL auto_increment,
  userID int(10) NOT NULL default '0',
  packageID int(10) NOT NULL default '0',
  objectType varchar(255) NOT NULL default '',
  objectID int(10) NOT NULL default '0',
  eventName varchar(255) NOT NULL default '',
  `time` int(10) NOT NULL default '0',
  shortOutput varchar(255) default NULL,
  mediumOutput text,
  longOutput text,
  confirmed tinyint(1) NOT NULL,
  confirmationTime int(10) NOT NULL default '0',
  additionalData text,
  PRIMARY KEY  (notificationID),
  KEY packageID (packageID)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table 'wcf1_user_notification_event'
--

DROP TABLE IF EXISTS wcf1_user_notification_event;
CREATE TABLE wcf1_user_notification_event (
  eventID int(10) NOT NULL auto_increment,
  packageID int(10) NOT NULL default '0',
  eventName varchar(255) NOT NULL default '',
  objectType varchar(255) NOT NULL default '',
  classFile varchar(255) NOT NULL default '',
  languageCategory varchar(255) NOT NULL,
  defaultNotificationType varchar(255) NOT NULL,
  icon varchar(255) NOT NULL,
  requiresConfirmation tinyint(1) NOT NULL default '0',
  acceptURL varchar(255) NOT NULL default '',
  declineURL varchar(255) NOT NULL default '',
  permissions text,
  options text,  
  PRIMARY KEY  (eventID),
  UNIQUE KEY packageID (packageID,eventName)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table 'wcf1_user_notification_message'
--

DROP TABLE IF EXISTS wcf1_user_notification_message;
CREATE TABLE wcf1_user_notification_message (
  messageID int(10) NOT NULL auto_increment,
  notificationID int(10) NOT NULL default '0',
  transportID int(10) NOT NULL default '0',
  notificationType varchar(255) NOT NULL default '',
  messageCache text,
  PRIMARY KEY  (messageID),
  UNIQUE KEY notificationID (notificationID,notificationType)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table 'wcf1_user_notification_object_type'
--

DROP TABLE IF EXISTS wcf1_user_notification_object_type;
CREATE TABLE wcf1_user_notification_object_type (
  objectTypeID int(10) NOT NULL auto_increment,
  packageID int(10) NOT NULL,
  objectType varchar(255) NOT NULL,
  classFile varchar(255) NOT NULL,  
  permissions text,
  options text,  
  PRIMARY KEY  (objectTypeID),
  UNIQUE KEY packageID (packageID,objectType)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table 'wcf1_user_notification_type'
--

DROP TABLE IF EXISTS wcf1_user_notification_type;
CREATE TABLE wcf1_user_notification_type (
  notificationTypeID int(10) NOT NULL auto_increment,
  packageID int(10) NOT NULL,
  notificationType varchar(255) NOT NULL,
  classFile varchar(255) NOT NULL,
  permissions text,
  options text,  
  PRIMARY KEY  (notificationTypeID)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table 'wcf1_user_notification_event_to_user'
--

DROP TABLE IF EXISTS wcf1_user_notification_event_to_user;
CREATE TABLE wcf1_user_notification_event_to_user (
  userID int(10) NOT NULL default '0',
  packageID int(10) NOT NULL default '0',
  objectType varchar(255) NOT NULL default '',
  eventName varchar(255) NOT NULL default '',
  notificationType varchar(255) NOT NULL default '',
  enabled tinyint(1) NOT NULL default '0',
  KEY userID (userID,packageID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE wcf1_user ADD notificationFlags TEXT NULL DEFAULT NULL
